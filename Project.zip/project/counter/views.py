from django.shortcuts import render

def home(request):
        return render(request, 'home.html')
def about(request):
        return render(request, 'about.html')
def count(request):
        full_text = request.GET['fulltext']
       
        # 총 단어수 세는 기능 (공백 기준으로 분리함)
        word_list = full_text.split()

        # 각 단어별로 나온 횟수 세는 기능
        word_dictionary = {} # 비어있는 딕셔너리 생성
        for word in word_list:
            if word in word_dictionary: # 이미 있으면 1 증가
                word_dictionary[word] += 1
            else: # 없으면 새로 생성
                word_dictionary[word] = 1

        return render(request, 'count.html', {'fulltext' : full_text,
        'total' : len(word_list), 'dictionary' : word_dictionary.items()})

# Create your views here.
